<?php
  /**
  * Projekt: modified eCommerce Shopsoftware
  * Modul: BX Modified Affiliates
  * Datei: admin/includes/extra/css/bx_modified_affiliates.php
  *
  * Datei-Header:
  * - Bindet modulbezogene CSS-Regeln fuer die Admin-Seite `bx_modified_affiliates.php` ein.
  * - Ausgabe erfolgt nur, wenn die aktuelle Seite `bx_modified_affiliates.php` ist.
  *
  * @package    BX_Modified_Affiliates
  * @author     Axel Benkert <info@bx-coding.de>
  * @copyright  (c) 2026
  * @version    1.0.0
  * @since      2026-08-23
  */

  defined('_VALID_XTC') or die('Direct Access to this location is not allowed.');

  if (basename($_SERVER['PHP_SELF']) == 'bx_modified_affiliates.php') {
?>
<style>
.bx-affiliates-panel {
  margin: 6px 10px;
  padding: 12px 12px 10px 12px !important;
  background: #fdfdfd;
  border: 1px solid #d9d9d9;
    border-left-width: 1px;
    border-left-style: solid;
    border-left-color: rgb(217, 217, 217);
  border-left: 3px solid #af417e;
  border-radius: 4px;
  box-shadow: inset 0 1px 0 #ffffff;
}

.bx-affiliates-table {
  width: calc(100% - 20px);
  margin: 6px 10px 12px;
  border: 1px solid #d9d9d9;
  border-left: 3px solid #af417e;
  border-radius: 4px;
  border-spacing: 0;
  background: #fdfdfd;
  box-shadow: inset 0 1px 0 #ffffff;
  color: #444444;
}

.bx-affiliates-table th,
.bx-affiliates-table td {
  padding: 8px 10px;
  border-bottom: 1px solid #e7e7e7;
  text-align: left;
}

.bx-affiliates-table th {
  background: #f3f3f3;
  color: #5a5a5a;
  font-weight: bold;
  white-space: nowrap;
}
.bx-affiliates-table th .container {
  display: inline-flex;
  flex-direction: row;
  flex-wrap: wrap;
  justify-content: flex-start;
  align-items: center;
  align-content: flex-start;
  gap: 4px;
}

.boxRight .container {
  display: grid;
  grid-template-columns: repeat(2, 1fr);
  grid-template-rows: repeat(1, 1fr);
  gap: 2px;
}

.bx-affiliates-table tr:last-child td {
  border-bottom: 0;
}

.bx-affiliates-table tbody tr:hover td,
.bx-affiliates-table tr:not(:first-child):hover td {
  background: #fff7fb;
  cursor: pointer;
}

.bx-affiliates-table tbody tr.bx-affiliates-selected td,
.bx-affiliates-table tr:not(:first-child).bx-affiliates-selected td {
  background: #ffdaec;
  cursor: pointer;
}


button.but_green {
  margin: 0 !important;
  color:#ddd;
  background-color:#7a8d47;
  border-color: #617234;
}

button.but_green:hover {
  color:#fff;
  background-color:#6e803d;
  border-color: #637434;
  text-decoration:none !important;
  cursor:pointer;
}
</style>
<?php
  }
?>