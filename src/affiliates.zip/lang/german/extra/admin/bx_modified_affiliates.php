<?php
/** 
 * BX BX Modified Affiliates - Deutsche Sprachtexte
 * 
 * Interface-Texte für das BX Modified Affiliates Modul (Admin-Bereich).
 * Alle UI-Elemente, Buttons und Beschreibungen in deutscher Sprache.
 * 
 * @package    BX Modified Affiliates
 * @subpackage Language
 * @category   Admin
 * @author     Axel Benkert
 * @version    1.0.0
 * @date       2026-08-22
 * @copyright  2020-2026 Axel Benkert
 * @license    GNU General Public License
 */

  define('BX_AFFILIATES_HEADING_TITLE', 'BX Modified Affiliates');
  define('BX_AFFILIATES_HEADING_PARTNER_TITLE', 'Partnerübersicht');
  define('BX_AFFILIATES_HEADING_TITLE_SEARCH', 'Suche');
  define('TEXT_NO_CHILD_CATEGORIES_OR_PRODUCTS', 'Keine Partner gefunden.');

  define('TABLE_HEADING_AFFILIATE_ID', 'Affiliate ID');
  define('TABLE_HEADING_LASTNAME', 'Nachname');
  define('TABLE_HEADING_FIRSTNAME', 'Vorname');
  define('TABLE_HEADING_COMMISSION', 'Provision');
  define('TABLE_HEADING_ACCOUNT', 'Konto');
  define('TABLE_HEADING_USERHOMEPAGE', 'Homepage');
  define('TABLE_HEADING_OPEN_COMMISSION', 'Offene Provision');
  defined('TABLE_HEADING_ACTION') or define('TABLE_HEADING_ACTION', 'Aktion');
 
// Detail-Infobox (rechte Spalte)
define('TEXT_INFO_DATE_ACCOUNT_CREATED', 'Erstellt am');
define('TEXT_INFO_DATE_ACCOUNT_LAST_MODIFIED', 'Zuletzt geändert');
define('TEXT_INFO_DATE_LAST_LOGON', 'Letzter Login');
define('TEXT_INFO_NEVER', 'Noch nie');
define('TEXT_INFO_NUMBER_OF_LOGONS', 'Anzahl Logins');
define('TEXT_INFO_COUNTRY', 'Land');
define('TEXT_INFO_COMMISSION_PERCENT', 'Provisionssatz');
define('TEXT_INFO_TIERS_ALLOWED', 'Mehrstufig (Tiers)');
define('TEXT_INFO_YES', 'Ja');
define('TEXT_INFO_NO', 'Nein');
define('TEXT_INFO_SALES_COUNT', 'Anzahl Verkäufe');
define('TEXT_INFO_SALES_TOTAL', 'Umsatz gesamt');
define('TEXT_INFO_COMMISSION_TOTAL', 'Provision gesamt');
define('TEXT_INFO_OPEN_COMMISSION', 'Offene Provision');
define('TEXT_INFO_NO_SELECTION_HEADING', 'Keine Auswahl');
define('TEXT_INFO_NO_SELECTION', 'Bitte einen Partner aus der Liste auswählen.');