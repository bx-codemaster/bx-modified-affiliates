<?php
/**
 * BX Modified Affiliates Module - Affiliate Management System
 * 
 * Professional affiliate management system for modified eCommerce with comprehensive
 * features for handling affiliate programs and commissions.
 *
 * @package    BX Modified Affiliates
 * @version    1.0.0
 * @author     See credits below
 * @copyright  2006-2026
 * @license    GNU General Public License v2.0
 * @link       https://www.modified-shop.org
 *
 */

  include('includes/application_top.php');

  //display per page
  defined('MAX_DISPLAY_LIST_AFFILIATES') or define('MAX_DISPLAY_LIST_AFFILIATES', 10);
  $cfg_max_display_results_key = 'MAX_DISPLAY_LIST_AFFILIATES';
  $page_max_display_results    = xtc_cfg_save_max_display_results($cfg_max_display_results_key);

  $search  = (isset($_GET['search'])  ? trim($_GET['search']) : '');
  $sorting = (isset($_GET['sorting']) ? $_GET['sorting'] : '');
  $page    = (isset($_GET['page'])    ? (int)$_GET['page'] : 1);
  $acID    = (isset($_GET['acID'])    ? (int)$_GET['acID'] : null);

  if (isset($_GET['ajax']) && $_GET['ajax'] === 'affiliate_details') {
    if (!isset($currencies) || !is_object($currencies)) {
      require_once(DIR_WS_CLASSES . 'currencies.php');
      $currencies = new currencies();
    }

    $affiliate_query = xtc_db_query("SELECT ap.bx_affiliate_id,
                                            ap.bx_affiliate_lastname,
                                            ap.bx_affiliate_firstname,
                                            ap.bx_affiliate_commission_percent,
                                            ap.bx_affiliate_country_id,
                                            ap.bx_affiliate_date_account_created AS date_account_created,
                                            ap.bx_affiliate_date_account_last_modified AS date_account_last_modified,
                                            ap.bx_affiliate_date_of_last_logon AS date_last_logon,
                                            ap.bx_affiliate_number_of_logons AS number_of_logons,
                                            ap.bx_affiliate_tiers_allowed
                                       FROM " . TABLE_BX_AFFILIATE_PARTNER . " ap
                                      WHERE ap.bx_affiliate_id = '" . $acID . "'");
    $affiliate = xtc_db_fetch_array($affiliate_query);

    header('Content-Type: application/json; charset=utf-8');
    if (!$affiliate) {
      echo json_encode(array(
        'success' => false,
        'csrf_name'  => $_SESSION['CSRFName'] ?? '',
        'csrf_token' => $_SESSION['CSRFToken'] ?? ''
      ));
      exit;
    }

    $country_query = xtc_db_query("SELECT countries_name FROM " . TABLE_COUNTRIES . " WHERE countries_id = '" . (int)$affiliate['bx_affiliate_country_id'] . "'");
    $country = xtc_db_fetch_array($country_query);

    $sales_summary_query = xtc_db_query("SELECT COUNT(*) AS sales_count,
                                                SUM(a.bx_affiliate_value) AS sales_total,
                                                SUM(a.bx_affiliate_payment) AS commission_total
                                           FROM " . TABLE_BX_AFFILIATE_SALES . " a,
                                                " . TABLE_ORDERS . " o
                                          WHERE a.bx_affiliate_orders_id = o.orders_id " . bx_affiliate_build_orders_status_query() . "
                                            AND a.bx_affiliate_id = '" . $acID . "'");
    $sales_summary = xtc_db_fetch_array($sales_summary_query);

    $oldday = (new DateTime())->modify('-' . BX_AFFILIATE_BILLING_TIME . ' days')->format('Y-m-d');
    $open_commission_query = xtc_db_query("SELECT SUM(a.bx_affiliate_payment) AS amount
                                             FROM " . TABLE_BX_AFFILIATE_SALES . " a,
                                                  " . TABLE_ORDERS . " o
                                            WHERE a.bx_affiliate_billing_status != 1
                                              AND a.bx_affiliate_orders_id = o.orders_id " . bx_affiliate_build_orders_status_query() . "
                                              AND a.bx_affiliate_id = '" . $acID . "'
                                              AND a.bx_affiliate_date <= '" . $oldday . "'");
    $open_commission_result = xtc_db_fetch_array($open_commission_query);
    $open_commission        = $open_commission_result['amount'] !== null ? (float)$open_commission_result['amount'] : 0.0;

    $heading = array(array('text' => xtc_output_string($affiliate['bx_affiliate_firstname']) . ' ' . xtc_output_string($affiliate['bx_affiliate_lastname'])));

    $contents = array();
    $contents[] = array('text' => '<div class="container"><div>' . TEXT_INFO_DATE_ACCOUNT_CREATED . '</div><div>' . xtc_date_short($affiliate['date_account_created']) . '</div></div>');
    $contents[] = array('text' => '<div class="container"><div>' . TEXT_INFO_DATE_ACCOUNT_LAST_MODIFIED . '</div><div>' . xtc_date_short($affiliate['date_account_last_modified']) . '</div></div>');
    $contents[] = array('text' => '<div class="container"><div>' . TEXT_INFO_DATE_LAST_LOGON . '</div><div>' . ($affiliate['date_last_logon'] ? xtc_date_short($affiliate['date_last_logon']) : TEXT_INFO_NEVER) . '</div></div>');
    $contents[] = array('text' => '<div class="container"><div>' . TEXT_INFO_NUMBER_OF_LOGONS . '</div><div>' . (int)$affiliate['number_of_logons'] . '</div></div>');
    $contents[] = array('text' => '<div class="container"><div>' . TEXT_INFO_COUNTRY . '</div><div>' . xtc_output_string($country['countries_name']) . '</div></div>');
    $contents[] = array('text' => '<hr/>');
    $contents[] = array('text' => '<div class="container"><div>' . TEXT_INFO_COMMISSION_PERCENT . '</div><div>' . xtc_output_string($affiliate['bx_affiliate_commission_percent']) . '%</div></div>');
    $contents[] = array('text' => '<div class="container"><div>' . TEXT_INFO_TIERS_ALLOWED . '</div><div>' . ((int)$affiliate['bx_affiliate_tiers_allowed'] === 1 ? TEXT_INFO_YES : TEXT_INFO_NO) . '</div></div>');
    $contents[] = array('text' => '<hr/>');
    $contents[] = array('text' => '<div class="container"><div>' . TEXT_INFO_SALES_COUNT . '</div><div>' . (int)$sales_summary['sales_count'] . '</div></div>');
    $contents[] = array('text' => '<div class="container"><div>' . TEXT_INFO_SALES_TOTAL . '</div><div>' . $currencies->format((float)$sales_summary['sales_total']) . '</div></div>');
    $contents[] = array('text' => '<div class="container"><div>' . TEXT_INFO_COMMISSION_TOTAL . '</div><div>' . $currencies->format((float)$sales_summary['commission_total']) . '</div></div>');
    $contents[] = array('text' => '<div class="container"><div>' . TEXT_INFO_OPEN_COMMISSION . '</div><div>' . $currencies->format($open_commission) . '</div></div>');

    $box = new box;
    echo json_encode(array(
      'success' => true, 
      'html' => $box->infoBox($heading, $contents),
      'csrf_name'  => $_SESSION['CSRFName'] ?? '',
      'csrf_token' => $_SESSION['CSRFToken'] ?? ''
      ));
    exit;
  }
  
  if (xtc_not_null($sorting)) {
    switch ($sorting) {
      case 'affiliate-id':
        $affiliate_sort = 'ap.bx_affiliate_id ASC';
        break;
      case 'affiliate-id-desc':
        $affiliate_sort = 'ap.bx_affiliate_id DESC';
        break;
      case 'lastname':
        $affiliate_sort = 'ap.bx_affiliate_lastname ASC';
        break;
      case 'lastname-desc':
        $affiliate_sort = 'ap.bx_affiliate_lastname DESC';
        break;
      case 'firstname':
        $affiliate_sort = 'ap.bx_affiliate_firstname ASC';
        break;
      case 'firstname-desc':
        $affiliate_sort = 'ap.bx_affiliate_firstname DESC';
        break;
      case 'commission':
        $affiliate_sort = 'ap.bx_affiliate_commission_percent ASC';
        break;
      case 'commission-desc':
        $affiliate_sort = 'ap.bx_affiliate_commission_percent DESC';
        break;
      case 'open-commission':
        $affiliate_sort = 'ap.bx_affiliate_payment ASC';
        break;
      case 'open-commission-desc':
        $affiliate_sort = 'ap.bx_affiliate_payment DESC';
        break;
      case 'account':
        $affiliate_sort = 'ap.bx_affiliate_email_address ASC';
        break;
      case 'account-desc':
        $affiliate_sort = 'ap.bx_affiliate_email_address DESC';
        break;
      case 'userhomepage':
        $affiliate_sort = 'ap.bx_affiliate_homepage ASC';
        break;
      case 'userhomepage-desc':
        $affiliate_sort = 'ap.bx_affiliate_homepage DESC';
        break;
      default:
        $affiliate_sort = 'ap.bx_affiliate_id DESC';
        break;
    }
  } else {
    $affiliate_sort = 'ap.bx_affiliate_id DESC';
  }

  $affiliate_sort .= ', ap.bx_affiliate_id DESC';

  if (!isset($currencies) || !is_object($currencies)) {
    require_once(DIR_WS_CLASSES . 'currencies.php');
    $currencies = new currencies();
  }

  require (DIR_WS_INCLUDES.'head.php');
?>
</head>
  <body>
    <!-- header //-->
    <?php require(DIR_WS_INCLUDES . 'header.php'); ?>
    <!-- header_eof //-->
    <!-- body //-->
    <table class="tableBody">
      <tr>
        <?php //left_navigation
        if (USE_ADMIN_TOP_MENU == 'false') {
          echo '<td class="columnLeft2">'.PHP_EOL;
          echo '<!-- left_navigation //-->'.PHP_EOL;       
          require_once(DIR_WS_INCLUDES . 'column_left.php');
          echo '<!-- left_navigation eof //-->'.PHP_EOL; 
          echo '</td>'.PHP_EOL;      
        }
        ?>
        <!-- body_text //-->
        <td class="boxCenter">
      
          <div class="pageHeadingImage">
            <?php echo xtc_image(DIR_WS_ICONS.'heading/bx_modified_affiliates.png', BX_AFFILIATES_HEADING_TITLE, '', '', 'style="height:100%;"'); ?>
          </div>
          <div class="pageHeading pdg2 flt-l">
            <?php echo BX_AFFILIATES_HEADING_TITLE; ?>
            <div class="main pdg2"><?php echo BX_AFFILIATES_HEADING_PARTNER_TITLE; ?></div> 
          </div> 
          
          <table class="tableCenter">
            <tr>
              <td class="boxCenterLeft">
                <div id="headboard" style="justify-content: space-between;">
                  <div class="main">
                    <span style="font-size: 1.25rem;">🤝🏼</span> <strong><?php echo BX_AFFILIATES_HEADING_TITLE; ?></strong>
                  </div>
                  <!--// Eventuel kann man das mal brauchen?
                  <div class="main">
                    <?php
                    echo xtc_draw_pull_down_menu('search_field', array(
                      array('id' => 'affiliate_id', 'text' => TABLE_HEADING_AFFILIATE_ID),
                      array('id' => 'lastname',     'text' => TABLE_HEADING_LASTNAME),
                      array('id' => 'firstname',    'text' => TABLE_HEADING_FIRSTNAME),
                      array('id' => 'commission',   'text' => TABLE_HEADING_COMMISSION),
                      array('id' => 'account',      'text' => TABLE_HEADING_ACCOUNT),
                      array('id' => 'userhomepage', 'text' => TABLE_HEADING_USERHOMEPAGE)
                    ), '', 'class="bx-affiliates-select"');
                    ?>
                  </div>
                  //-->  
                  <div class="main">
                    <?php
                      echo xtc_draw_form('search', BX_FILENAME_AFFILIATES, '', 'get', 'style="display: inline-flex; height: auto; align-items: flex-start; justify-content: flex-end; gap: 5px;"');
                      echo '<span>' . BX_AFFILIATES_HEADING_TITLE_SEARCH . ':</span>' . xtc_draw_input_field('search', $search);
                      echo '<button type="submit" style="background: none; border: none; padding: 0; margin: 0; cursor: pointer;">
                              ' . xtc_image(DIR_WS_ICONS.'fastnav/icon_search.png', 'Suche', '30px') . '
                            </button>';
                    ?>
                    </form>
                  </div>
                </div>

                <div class="boxCenter">
                  <table class="bx-affiliates-table">
                    <tr>
                      <th>
                        <div class="container"><?php echo '<span>' . TABLE_HEADING_AFFILIATE_ID . '</span><span>' . str_replace('<br />', '', xtc_sorting(BX_FILENAME_AFFILIATES, 'affiliate-id')) . '</span>'; ?></div>
                      </th>
                      <th>
                        <div class="container"><?php echo '<span>' . TABLE_HEADING_LASTNAME . '</span><span>' . str_replace('<br />', '', xtc_sorting(BX_FILENAME_AFFILIATES, 'lastname')) . '</span>'; ?></div>
                      </th>
                      <th>
                        <div class="container"><?php echo '<span>' . TABLE_HEADING_FIRSTNAME . '</span><span>' . str_replace('<br />', '', xtc_sorting(BX_FILENAME_AFFILIATES, 'firstname')) . '</span>'; ?></div>
                      </th>
                      <th>
                        <div class="container"><?php echo '<span>' . TABLE_HEADING_COMMISSION . '</span><span>' . str_replace('<br />', '', xtc_sorting(BX_FILENAME_AFFILIATES, 'commission')) . '</span>'; ?></div>
                      </th>
                      <th>                       
                        <div class="container"><?php echo '<span>' . TABLE_HEADING_OPEN_COMMISSION . '</span><span>' . str_replace('<br />', '', xtc_sorting(BX_FILENAME_AFFILIATES, 'open-commission')) . '</span>'; ?></div>
                      </th>
                      <th>
                        <div class="container"><?php echo '<span>' . TABLE_HEADING_ACCOUNT . '</span><span>' . str_replace('<br />', '', xtc_sorting(BX_FILENAME_AFFILIATES, 'account')) . '</span>'; ?></div>
                      </th>
                      <th>
                        <div class="container"><?php echo '<span>' . TABLE_HEADING_USERHOMEPAGE . '</span><span>' . str_replace('<br />', '', xtc_sorting(BX_FILENAME_AFFILIATES, 'userhomepage')) . '</span>'; ?></div>
                      </th>
                      <th>
                        <?php echo TABLE_HEADING_ACTION; ?>
                      </th>
                    </tr>
                    <?php
                    $rows = ($page > 1) ? $page * $page_max_display_results - $page_max_display_results : 0;

                    $where = '';
                    if (xtc_not_null($search)) {
                      $search_db = xtc_db_input($search);
                      $where = " WHERE (CAST(ap.bx_affiliate_id AS CHAR) LIKE '%" . $search_db . "%'
                                 OR ap.bx_affiliate_lastname LIKE '%" . $search_db . "%'
                                 OR ap.bx_affiliate_firstname LIKE '%" . $search_db . "%'
                                 OR ap.bx_affiliate_email_address LIKE '%" . $search_db . "%'
                                 OR ap.bx_affiliate_homepage LIKE '%" . $search_db . "%')";
                    }

                    $affiliates_query_raw = "SELECT ap.bx_affiliate_id,
                                                    ap.bx_affiliate_lastname,
                                                    ap.bx_affiliate_firstname,
                                                    ap.bx_affiliate_commission_percent,
                                                    ap.bx_affiliate_email_address,
                                                    ap.bx_affiliate_homepage,
                                                    ap.bx_affiliate_country_id
                                   FROM " . TABLE_BX_AFFILIATE_PARTNER . " ap"
                                           . $where
                                           . " ORDER BY " . $affiliate_sort;

                    $affiliates_query_numrows = 0;
                    $affiliates_split = new splitPageResults($page, $page_max_display_results, $affiliates_query_raw, $affiliates_query_numrows, 'bx_affiliate_id');
                    $affiliates_query = xtc_db_query($affiliates_query_raw);

                    // Alle Zeilen der aktuellen Seite vorab einlesen (klein dank Pagination) - so lässt sich
                    // vorab feststellen, ob acID überhaupt in der (ggf. gefilterten) Ergebnismenge vorkommt,
                    // bevor die erste <tr> ausgegeben wird.
                    $affiliates = array();
                    while ($row = xtc_db_fetch_array($affiliates_query)) {
                      $affiliates[] = $row;
                    }

                    // Effektive Auswahl bestimmen: kommt acID nicht in der Liste vor (z. B. Default-Wert,
                    // gelöschter Partner, oder Suche/Sortierung ohne Treffer), wird die erste Zeile markiert.
                    $acID_effective = $acID;
                    $acID_found     = false;

                    foreach ($affiliates as $row) {
                      if ((int)$row['bx_affiliate_id'] === $acID) {
                        $acID_found = true;
                        break;
                      }
                    }

                    if (!$acID_found && !empty($affiliates)) {
                      $acID_effective = (int)$affiliates[0]['bx_affiliate_id'];
                    }

                    $oldday = (new DateTime())->modify('-' . BX_AFFILIATE_BILLING_TIME . ' days')->format('Y-m-d');

                    $aInfo = null;   // außerhalb der Schleife -> bleibt nach dem Durchlauf für die rechte Box erhalten

                    foreach ($affiliates as $affiliate) {
                      $is_selected = ((int)$affiliate['bx_affiliate_id'] === $acID_effective);

                      // Offene Provision je Zeile (für die neue Spalte) - immer berechnet, unabhängig von der Auswahl
                      $acnt_value = xtc_db_query("SELECT sum(a.bx_affiliate_payment) AS amount 
                                                          FROM " . TABLE_BX_AFFILIATE_SALES . " a, 
                                                               " . TABLE_ORDERS . " o 
                                                        WHERE a.bx_affiliate_billing_status != 1 
                                                          AND a.bx_affiliate_orders_id = o.orders_id " . bx_affiliate_build_orders_status_query() . " 
                                                          AND a.bx_affiliate_id = '" . $affiliate['bx_affiliate_id'] . "' 
                                                          AND a.bx_affiliate_date <= '" . $oldday . "'");

                      $acnt_res = xtc_db_fetch_array($acnt_value);
                      $open_commission = $acnt_res['amount'] !== null ? (float)$acnt_res['amount'] : 0.0;

                      // Detail-Aggregation nur einmal für die tatsächlich ausgewählte Zeile (nicht pro Zeile,
                      // um unnötige zusätzliche Queries für alle anderen Partner der Seite zu vermeiden).
                      if ($is_selected && !$aInfo) {
                        $info_query = xtc_db_query("SELECT bx_affiliate_commission_percent, 
                                                                  bx_affiliate_date_account_created AS date_account_created, 
                                                                  bx_affiliate_date_account_last_modified AS date_account_last_modified, 
                                                                  bx_affiliate_date_of_last_logon AS date_last_logon, 
                                                                  bx_affiliate_number_of_logons AS number_of_logons,
                                                                  bx_affiliate_tiers_allowed 
                                                              FROM " . TABLE_BX_AFFILIATE_PARTNER . " 
                                                            WHERE bx_affiliate_id = '" . $affiliate['bx_affiliate_id'] . "'");
                        $info = xtc_db_fetch_array($info_query);

                        $country_query = xtc_db_query("SELECT countries_name FROM " . TABLE_COUNTRIES . " WHERE countries_id = '" . $affiliate['bx_affiliate_country_id'] . "'");
                        $country       = xtc_db_fetch_array($country_query);

                        $sales_summary_query = xtc_db_query("SELECT COUNT(*) AS sales_count, 
                                                                     SUM(a.bx_affiliate_value)   AS sales_total, 
                                                                     SUM(a.bx_affiliate_payment) AS commission_total 
                                                                FROM " . TABLE_BX_AFFILIATE_SALES . " a, 
                                                                     " . TABLE_ORDERS . " o 
                                                               WHERE a.bx_affiliate_orders_id = o.orders_id " . bx_affiliate_build_orders_status_query() . " 
                                                                 AND a.bx_affiliate_id = '" . $affiliate['bx_affiliate_id'] . "'");
                        $sales_summary = xtc_db_fetch_array($sales_summary_query);

                        $affiliate_info = array_merge($country, $info, $sales_summary, array('open_commission' => $open_commission));
                        $aInfo_array    = array_merge($affiliate, $affiliate_info);
                        $aInfo          = new objectInfo($aInfo_array);
                      }

                      if ($is_selected) {
                        echo '<tr class="bx-affiliates-selected" data-affiliate-id="' . (int)$affiliate['bx_affiliate_id'] . '" data-edit-url="' . xtc_href_link(BX_FILENAME_AFFILIATES, xtc_get_all_get_params(array('acID', 'action')) . 'acID=' . $affiliate['bx_affiliate_id'] . '&action=edit') . '">' . PHP_EOL;
                      } else {
                        echo '<tr data-affiliate-id="' . (int)$affiliate['bx_affiliate_id'] . '" data-edit-url="' . xtc_href_link(BX_FILENAME_AFFILIATES, xtc_get_all_get_params(array('acID', 'action')) . 'acID=' . $affiliate['bx_affiliate_id'] . '&action=edit') . '">' . PHP_EOL;
                      }

                      $affiliate['bx_affiliate_homepage'] = bx_affiliate_normalize_url($affiliate['bx_affiliate_homepage']);

                      $rows++;
                    ?>
                      <td style="text-align: center;"><?php echo (int)$affiliate['bx_affiliate_id']; ?></td>
                      <td><?php echo xtc_output_string($affiliate['bx_affiliate_lastname']); ?></td>
                      <td><?php echo xtc_output_string($affiliate['bx_affiliate_firstname']); ?></td>
                      <td style="text-align: center;"><?php echo xtc_output_string($affiliate['bx_affiliate_commission_percent']); ?>%</td>
                      <td style="text-align: center;"><?php echo $currencies->format($open_commission); ?></td>
                      <td><?php echo xtc_output_string($affiliate['bx_affiliate_email_address']); ?></td>
                      <td><?php echo xtc_output_string($affiliate['bx_affiliate_homepage']); ?></td>
                      <td style="text-align: right;"><?php
                        if ( (is_object($aInfo)) && ($affiliate['bx_affiliate_id'] == $aInfo->bx_affiliate_id) ) {
                          echo xtc_image(DIR_WS_IMAGES . 'icon_arrow_right.gif', IMAGE_ICON_INFO);
                        } else {
                          echo xtc_image(DIR_WS_IMAGES . 'icon_arrow_grey.gif', IMAGE_ICON_INFO);
                        }
                      ?></td>
                    </tr>
                    <?php
                    }

                    if ($rows == 0) {
                    ?>
                    <tr>
                      <td colspan="8"><div class="error_message txta-c"><?php echo TEXT_NO_CHILD_CATEGORIES_OR_PRODUCTS; ?></div></td>
                    </tr>
                    <?php
                    }
                    ?>
                  </table>
                  <div class="bx-affiliates-panel" style="display: grid; grid-template-columns: repeat(2, 1fr); grid-template-rows: repeat(2, 1fr); gap: 4px;">
                    <div class="smallText">
                      <?php echo $affiliates_split->display_count($affiliates_query_numrows, $page_max_display_results, $page, TEXT_DISPLAY_NUMBER_OF_PRODUCTS); ?>
                    </div>
                    <div class="smallText txta-r">
                      <?php echo $affiliates_split->display_links($affiliates_query_numrows, $page_max_display_results, MAX_DISPLAY_PAGE_LINKS, $page, xtc_get_all_get_params(array('page'))); ?>
                    </div>
                    <div class="smallText">
                      <?php echo draw_input_per_page($PHP_SELF, $cfg_max_display_results_key, $page_max_display_results); ?>
                    </div>
                  </div>
                </div> <!-- .boxCenter //-->

              </td>
              <!-- boxCenterLeft //-->
              <td class="boxRight" id="bx-affiliate-details">
                <?php
                $heading  = array();
                $contents = array();
                if (is_object($aInfo)) { 
                  $heading[]  = array('text' => xtc_output_string($aInfo->bx_affiliate_firstname) . ' ' . xtc_output_string($aInfo->bx_affiliate_lastname));
                  $contents[] = array('text' => '<div class="container">
                    <div>' . TEXT_INFO_DATE_ACCOUNT_CREATED . '</div>
                    <div>' . xtc_date_short($aInfo->date_account_created) . '</div>
                  </div>');
                  $contents[] = array('text' => '<div class="container">
                    <div>' . TEXT_INFO_DATE_ACCOUNT_LAST_MODIFIED . '</div>
                    <div>' . xtc_date_short($aInfo->date_account_last_modified) . '</div>
                  </div>');
                  $contents[] = array('text' => '<div class="container">
                    <div>' . TEXT_INFO_DATE_LAST_LOGON . '</div>
                    <div>' . ($aInfo->date_last_logon ? xtc_date_short($aInfo->date_last_logon) : TEXT_INFO_NEVER) . '</div>
                  </div>');
                  $contents[] = array('text' => '<div class="container">
                    <div>' . TEXT_INFO_NUMBER_OF_LOGONS . '</div>
                    <div>' . (int)$aInfo->number_of_logons . '</div>
                  </div>');
                  $contents[] = array('text' => '<div class="container">
                    <div>' . TEXT_INFO_COUNTRY . '</div>
                    <div>' . xtc_output_string($aInfo->countries_name) . '</div>
                  </div>');
                  $contents[] = array('text' => '<hr/>');
                  $contents[] = array('text' => '<div class="container">
                    <div>' . TEXT_INFO_COMMISSION_PERCENT . '</div>
                    <div>' . xtc_output_string($aInfo->bx_affiliate_commission_percent) . '%</div>
                  </div>');
                  $contents[] = array('text' => '<div class="container">
                    <div>' . TEXT_INFO_TIERS_ALLOWED . '</div>
                    <div>' . ((int)$aInfo->bx_affiliate_tiers_allowed === 1 ? TEXT_INFO_YES : TEXT_INFO_NO) . '</div>
                  </div>');
                  $contents[] = array('text' => '<hr/>');
                  $contents[] = array('text' => '<div class="container">
                    <div>' . TEXT_INFO_SALES_COUNT . '</div>
                    <div>' . (int)$aInfo->sales_count . '</div>
                  </div>');
                  $contents[] = array('text' => '<div class="container">
                    <div>' . TEXT_INFO_SALES_TOTAL . '</div>
                    <div>' . $currencies->format((float)$aInfo->sales_total) . '</div>
                  </div>');
                  $contents[] = array('text' => '<div class="container">
                    <div>' . TEXT_INFO_COMMISSION_TOTAL . '</div>
                    <div>' . $currencies->format((float)$aInfo->commission_total) . '</div>
                  </div>');
                  $contents[] = array('text' => '<div class="container">
                    <div>' . TEXT_INFO_OPEN_COMMISSION . '</div>
                    <div>' . $currencies->format((float)$aInfo->open_commission) . '</div>
                  </div>');
                } else {
                  $heading[]  = array('text' => TEXT_INFO_NO_SELECTION_HEADING);
                  $contents[] = array('text' => TEXT_INFO_NO_SELECTION);
                }
                if ( (xtc_not_null($heading)) && (xtc_not_null($contents)) ) {
                  $box = new box;
                  echo $box->infoBox($heading, $contents);
                }                
                ?>
              </td>
            </tr>
          </table>

        </td>
      </tr>
    </table>
    <?php require(DIR_WS_INCLUDES . 'footer.php'); ?>
    <script>
      $(document).ready(function() {
        setTimeout(function(){ $(".fixed_messageStack").hide("slow"); }, 3000);
      });
    </script>
  </body>
</html>
<?php require(DIR_WS_INCLUDES . 'application_bottom.php'); ?>
